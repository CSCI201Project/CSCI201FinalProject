package Chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import temporary.GameObject;
import temporary.GameObjectHandler;
import temporary.PlayerChar;
import temporary.PlayingField;
import temporary.Window;

public class GamerClient implements Runnable, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4794938896816850493L;
	transient private PrintWriter pw;
	transient private BufferedReader br;
	transient private ObjectInputStream ois;
	private GameObjectHandler localHandler;
	private PlayerChar player;
	transient private Window frame;
	transient private Socket server;
	private Thread t;
	
	public GamerClient(String hostname, int port, Scanner scan){
		//this.player = new PlayerChar("Chris");
		frame = new Window(new PlayingField());
		//this.GUIsetup();
		//this.addEvents();
		
			try {
				this.server = new Socket(hostname, port);
				//this.pw = new PrintWriter(server.getOutputStream());
				//this.br = new BufferedReader(new InputStreamReader(server.getInputStream()));
				//this.oos = new ObjectOutputStream(server.getOutputStream());
				this.ois = new ObjectInputStream(this.server.getInputStream());
				t = new Thread(this);
				t.start();
				//while(true){
				//}
			} catch (UnknownHostException e) {
				System.out.println("Unknown Host: " +e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		
		
	}
	public void addEvents(){
		System.out.println("here");
		//pw.println(2);
		//pw.flush();
		
	}
	public void GUIsetup(){
		
	}
	public void run(){
		try {
			System.out.println("CONNECTED");
			boolean firstTime = true;
			PlayingField pf = null;
			while(true){
				/*Object o = this.ois.readObject();
				System.out.println(" object was read.");
				if(o instanceof PlayerChar){
					System.out.println("Got Player");
					
					if(firstTime){
						this.player = (PlayerChar) o;
						System.out.println("Got my Player: "+ this.player.getName());
						this.player.setPlayerType(GameObject.SURVIVOR);
						//pf = new PlayingField(player);
						//frame.setPlayingField(pf);
						
						firstTime = false;
					}
					
					else{
						PlayerChar tempChar = (PlayerChar) o;
						for(GameObject go: localHandler.getObjects()){
							if(tempChar.getID() == go.getID()){
								System.out.println("FOUND A MATCHING PLAYER");
								//go = tempChar;
								System.out.println("("+tempChar.getX()+", "+tempChar.getY()+")");
								
								go.setX(tempChar.getX());
								go.setY(tempChar.getY());
								break;
							}
						}
					}
				}
				else if(o instanceof GameObjectHandler){
					this.localHandler = (GameObjectHandler) o;
					if(pf != null){
						//
						//pf.setHandler(this.localHandler);
						frame.revalidate();
						System.out.println("Got Handler");
					}
				}*/
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String [] args){
		Scanner scan = new Scanner(System.in);
		GamerClient gc = new GamerClient("localhost",6789, scan);
		//10.121.54.219 
	}
}
