package weapons;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Vector;

import project2.GameObject;
import project2.ObjectId;

public class AssaultRifle extends Weapon{

	public AssaultRifle(ObjectId id) {
		super(id);
		this.currentAmmoCount = 30;
		this.maxAmmoCount = 90;
		this.ammoFromPickup = 15;
		this.bulletDamage = 60;
		this.fireRate = 2; //per second
		canFire = true;
	}

	public Bullet fireWeapon(int bulletX, int bulletY, String direction) {
		// TODO Auto-generated method stub
		currentAmmoCount = currentAmmoCount - 1;
		return new Bullet(ObjectId.Bullet, bulletX, bulletY, bulletDamage, false, direction);
	}

	public void addAmmo() {
		// TODO Auto-generated method stub
		currentAmmoCount += ammoFromPickup;
		if (currentAmmoCount > maxAmmoCount){currentAmmoCount = maxAmmoCount;}
	}

	

}
