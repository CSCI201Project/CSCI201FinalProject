package project2;

public enum ObjectId {
	HumanSurvivor(),
	HumanZombie(),
	AlphaZombie(),
	NormalZombie(),
	Tree(),
	Bush(),
	Tombstone(),
	Cross();
}
