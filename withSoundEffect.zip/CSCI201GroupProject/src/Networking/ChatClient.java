package Networking;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;

import characters.PlayerChar;
import project2.Window;

public class ChatClient extends JPanel implements Runnable, Serializable{

	private PrintWriter pw;
	private BufferedReader br;
	private ObjectOutputStream out;
	private ObjectInputStream in; 
	private Thread t  = new Thread(this);
	private JPanel outerPanel = new JPanel();
	private String line = ""; 
	private JTextArea messageHistoryArea = new JTextArea();
	private JTextField sendNewMessageArea = new JTextField();
	private JPanel south = new JPanel();
	private JButton clear = new JButton("clear");
	private JButton send = new JButton("send");
	private Player playerSent;
	private Player playerReceived;
	private Socket socket; 
	Timer timer;
	Random rd = new Random();
	JPanel panel = this;
	Client c;
	private JLabel label = new JLabel("dsadasd");

	public ChatClient(Socket s) throws IOException {
		//		super("Chat Software");
		System.out.println("Inside chatclient");
		try {
			socket = s;
			playerSent = new Player();
			
			System.out.println("created ");
			out = new ObjectOutputStream(socket.getOutputStream());
			System.out.println("OUT  created ");
			in = new ObjectInputStream(socket.getInputStream());
//			System.out.println("OUT and IN created ");
			
			t.start();
			outerPanel.setLayout(new BoxLayout(outerPanel, BoxLayout.Y_AXIS));
			Border mhBorder = BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.BLACK), BorderFactory.createEmptyBorder(10, 10, 10, 10));
			messageHistoryArea.setBorder(mhBorder);
			messageHistoryArea.setEnabled(false);
			messageHistoryArea.setDisabledTextColor(Color.BLACK);
			JScrollPane scrollPane = new JScrollPane (messageHistoryArea, 
					JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			scrollPane.setPreferredSize(new Dimension(500,500));
			//			scrollPane.setSize(100, 200);
			outerPanel.add(scrollPane);
			//			outerPanel.setSize(200,200);
			outerPanel.setPreferredSize(new Dimension(300,0));
			//			this.setPreferredSize(new Dimension(300,600));
			//			sendNewMessageArea.setPreferredSize(new Dimension(200,0));
			sendNewMessageArea.setText("Send new message by typing here...");
			sendNewMessageArea.setEditable(false);
			sendNewMessageArea.addMouseListener(new MouseListener() {

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseClicked(MouseEvent e) {
					sendNewMessageArea.setEditable(true);
					sendNewMessageArea.setText("");

				}
			});

			outerPanel.add(scrollPane);
			outerPanel.add(sendNewMessageArea);
			south.setLayout(new BorderLayout());
			south.add(clear, BorderLayout.WEST);
			south.add(send, BorderLayout.EAST);
			outerPanel.add(south);

			ActionListener reenableButton = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					send.setEnabled(true);

				}
			};
			timer = new Timer(500, reenableButton);
			ActionListener sendMessage = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					playerSent = new Player();
					playerSent.setMessage(sendNewMessageArea.getText()); 
					sendNewMessageArea.setText("");
					send.setEnabled(false);
					timer.start();
					timer.setRepeats(false);
					if(!playerSent.getMessage().equals("")){
						try {
							messageHistoryArea.append("From me: " + playerSent.getMessage() + "\n");
							System.out.println("Message flushed: " +playerSent.getMessage());
							out.writeObject(playerSent);
							out.flush();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					else{
						JOptionPane.showMessageDialog (panel, "Can not send empty messages! Please put in some words");
					}
				}
			};
			send.addActionListener(sendMessage);
			clear.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					sendNewMessageArea.setText("");
				}
			});
			this.setLayout(new BorderLayout());
			this.add(outerPanel, BorderLayout.CENTER);
		} 
		catch (IOException ioe) {
			System.out.println("ioe in ChatClient: " + ioe.getMessage());
		}
	}

	public void run() {
		try {
			System.out.println("IN RUN! " );
			while(true) {
				Player playerReceived = (Player) in.readObject();
				System.out.println("playerReceived.message:" + playerReceived.getMessage());
				if(playerReceived.getMessage()!=null){
					if(playerReceived.getMessage().equals("CONNECTED")){
						System.out.println("client connected");
					}
					else if(!playerReceived.getMessage().equals("null")&&!playerReceived.getMessage().equals("")){
						messageHistoryArea.append("From Player " + playerReceived.getPlayerNumber()+ ":"+playerReceived.getMessage()+ "\n");
					}
					else{
						System.out.println("The other client disconnected, disconnecting...");
						break;
					}
				}
				else {

				}
				//					}
				//				}
			} 
		}

		catch (IOException ioe) {
			System.out.println("ioe in run in ChatClient: " + ioe.getMessage());
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
