package Networking;

import java.awt.Window;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import project2.ObjectId;
import project2.PlayingField;
import characters.PlayerChar;

public class PlayerThread extends Thread{
	private Socket s;
	private Server cs;
	private PrintWriter pw;
	private ObjectOutputStream out;
	private int playerNumber;
	Player player;
	PlayerChar playerChar;
	
	public PlayerThread(Socket s, Server cs, int playerNumber) {
		this.s = s;
		this.cs = cs;
		this.playerNumber = playerNumber;
		playerChar = new PlayerChar("Ryan", 0, 0, ObjectId.HumanSurvivor);
//		System.out.println("MSG? : " +project2.Window.pf.getMsg());
//		project2.Window.pf.getGameObjectHandler().addPlayer("Ryan", 0, 0, ObjectId.HumanSurvivor);
		player = new Player(0,0);
		
		player.setPlayerNumber(playerNumber);
		System.out.println("Player number set to: " + player.getPlayerNumber());
//		player.setPlayerX(0);
//		player.setPlayerY(0);
		System.out.println("new player created: " + player.getMessage());
		try {
			this.out = new ObjectOutputStream(this.s.getOutputStream());
			
			
		} catch (IOException ioe) {
			System.out.println("ioe in PlayerThread: " + ioe.getMessage());
		}
	}
	
	public void send(String message, Player player) throws IOException {
		player.setMessage(message);
		System.out.println(" players number when you send msg: " + player.getPlayerNumber());
		this.out.writeObject(player);
		out.flush();
	}
	public Player getPlayer(){
		return this.player;
	}
	
	public void run() {
		try {
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
//			System.out.println("created inputstream : "+ in.reset(););
			while(true) {
//				System.out.println("Inside while true");
				Player playerReceived = (Player) in.readObject();
				playerReceived.setPlayerNumber(playerNumber);
				System.out.println("playerReceived playnumber: " + playerReceived.getPlayerNumber());
//				System.out.println("Read in something from inputstream");
				cs.sendPlayerObject(playerReceived, this);
			}
		} catch (IOException ioe) {
			cs.removePlayerThread(this);
			System.out.println("Client disconnected from " + s.getInetAddress());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
