package Networking;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JPanel;

import project2.PlayingField;
import characters.PlayerChar;

public class Client extends JPanel implements Serializable, Runnable{

	
	
	public static Player player;
	
	ObjectOutputStream out;
	public static ChatClient cc;
	static Socket s;
	public Client(String hostname, int port)  {

//		player=new Player();
		
		try {
			s = new Socket(hostname,port);
			cc = new ChatClient(s);
			
//			out = new ObjectOutputStream(s.getOutputStream());
//			out.writeObject(player);
//			out.flush();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
//	public void flushObject(PlayerChar player ) throws IOException{
////		ObjectOutputStream out = null;
//		out.writeObject(player);
//		out.flush();
//		
//	}
	public static void main(String[] args){
		new Client("localhost",5555);
	}
	
	public void run() {
		// TODO Auto-generated method stub
		
		
	}
}

