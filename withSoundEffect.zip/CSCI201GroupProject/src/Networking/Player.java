package Networking;

import java.io.Serializable;

public class Player implements Serializable {
	boolean ifHuman;
	String message = "null";
	int playerNumber = 20;
	double x;
	double y;
	int location;

	public Player(){
		
	}
	public Player(double x, double y){
		this.x = x;
		this.y = y;
	}
	
	public void setPlayerNumber(int pn){
		this.playerNumber = pn;
	}
	public int getPlayerNumber(){
		return this.playerNumber;
	}
	
	private double getPlayerX(){
		return this.x;
	}
	
	private double getPlayerY(){
		return this.y;
	}

	public void setPlayerY(double y){
		this.y = y;
	}
	
	public  void setPlayerX(double x){
		this.x = x;
	}
	
	public void setMessage(String message){
		this.message = message;
	}
	
	public String getMessage(){
		return this.message;
	}
}
