package Networking;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JFrame;

import characters.PlayerChar;

public class Server extends JFrame {

//	private ChatThread ct;
//	private ChatThread ct2;
	private PlayerThread pct;
	int numOfPlayers = 2;
//	private Vector<ChatThread> ctVector = new Vector<ChatThread>();
	private Vector<PlayerThread> ptVector = new Vector<PlayerThread>();
	
	public Server(int port) {
		super("sdasdas");
		try {
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Waiting for connections...");
//			int o=;
			for(int i=0;i<numOfPlayers;i++){
				Socket s = ss.accept();
				System.out.println("Connection from " + s.getInetAddress());
//				ct = new ChatThread(s, this);
//				ctVector.add(ct);
				pct = new PlayerThread(s, this, i+1);
				System.out.println("i iin for: " + (i+1));
				ptVector.add(pct);
			}
//			System.out.println("PCt vector size: " + ptVector.size());
			
			for(PlayerThread s:ptVector){
//				System.out.println("O: " + o);
				s.start();
//				System.out.println("thread started");
				s.send("CONNECTED", s.getPlayer());
//				System.out.println("send message went through");
				
			}
			System.out.println("ALL CLIENTS CONNECTED!");

		} catch (IOException ioe) {
			System.out.println("ioe in Server: " + ioe.getMessage());
		}
	}
//
//	public void sendMessage(String message, Thread ct) throws IOException {
//		for(ChatThread s: ctVector){
//			if(!s.equals(ct)){
//				s.send(message, );
//			}
//		}
//	}

	public void sendPlayerObject(Player player, PlayerThread pct) throws IOException{
		for(PlayerThread s: ptVector){
			if(!s.equals(pct)){
				s.send(player.getMessage(),player);
				System.out.println("sendPObject pn: " + player.getPlayerNumber());
			}
		}
	}
	
	public void removePlayerThread(PlayerThread pct){
		ptVector.remove(pct);
	}

	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("What port? ");
//		int port = scan.nextInt();
		new Server(5555);
	}
}