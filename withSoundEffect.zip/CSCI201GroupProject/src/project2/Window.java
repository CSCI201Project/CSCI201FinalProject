package project2;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;

import Networking.ChatClient;
import Networking.Client;

public class Window extends JFrame{
	public static PlayingField pf;
	private JLabel label = new JLabel("dsadasd");
	Window(PlayingField pf){
		this.setLayout(new BorderLayout());
		this.setSize(1000,600);
		this.setLocation(100, 50);
		this.setMinimumSize(new Dimension(800,600));
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Client c = new Client("localhost", 5555);
		c.cc.setPreferredSize(new Dimension(this.getWidth()/5,this.getHeight()));
		this.add(c.cc, BorderLayout.EAST);
		
		this.pf = pf;
		this.add(this.pf);
		Thread t = new Thread(pf);

		this.setVisible(true);
		t.start();
	}

	public static void main(String [] args){
		new Window(new PlayingField(new TimerThread(5)));
		
	}
}


