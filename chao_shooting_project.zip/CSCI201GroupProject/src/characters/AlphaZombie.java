package characters;

import project2.ObjectId;

public class AlphaZombie extends AIChar{

	public AlphaZombie(double x, double y, ObjectId id) {
		super(x,y,id);
	}

}
