package characters;

import project2.ObjectId;

public class Zombie extends AIChar{

	public Zombie(double x, double y, ObjectId id) {
		super(x, y,id);
	}

}
