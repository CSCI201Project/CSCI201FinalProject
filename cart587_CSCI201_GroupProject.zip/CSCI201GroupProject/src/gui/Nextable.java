package gui;

public interface Nextable {
	public void nextScreen();
}
