package characters;

import imageProcessing.Animation;
import project2.ObjectId;

public class AlphaZombie extends AIChar{

	public AlphaZombie(double x, double y, ObjectId id) {
		super(x,y,id);
		this.velX = 5;
		this.velY = 5;
		this.zombieWalk = new Animation(5, texture.alphaZombieWalkSprites);
		this.zombieAttack = new Animation(5, texture.alphaZombieAttackSprites);
		this.health = 150;
	}

}
