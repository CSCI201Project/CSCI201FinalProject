package characters;

import imageProcessing.Animation;
import project2.ObjectId;

public class Zombie extends AIChar{

	public Zombie(double x, double y, ObjectId id) {
		super(x, y,id);
		this.velX = 2;
		this.velY = 2;
		this.zombieWalk = new Animation(5, texture.normalZombieWalkSprites);
		this.zombieAttack = new Animation(3, texture.normalZombieAttackSprites);
		this.health = 100;
	}

}
