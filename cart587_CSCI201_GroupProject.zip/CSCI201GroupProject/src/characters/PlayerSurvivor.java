package characters;

public class PlayerSurvivor extends PlayerMovement{
	public PlayerSurvivor(PlayerChar player) {
		super(player);
	}

	synchronized public void attack() {
		player.fireWeapon();
	}
}
