package characters;

import gui.SoundPlayer;


public class PlayerSurvivor extends PlayerMovement{
	
	public PlayerSurvivor(PlayerChar player) {
		super(player);
	}

	public void attack() {
		if(!player.getWeapon().outOfAmmo()){
			SoundPlayer sp = new SoundPlayer("sound/shotgunsound.wav");
			sp.playSoundOnce();
			}
			else{
				SoundPlayer sp = new SoundPlayer("sound/gunclick.wav");
				sp.playSoundOnce();
			}
		player.fireWeapon();
	}

}
