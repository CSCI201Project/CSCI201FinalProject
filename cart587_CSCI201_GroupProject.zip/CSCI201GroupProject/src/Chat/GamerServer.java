package Chat;

import java.io.IOException;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

import temporary.GameObject;
import temporary.GameObjectHandler;
import temporary.PlayerChar;
import temporary.PlayingField;

public class GamerServer implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4908842286127571796L;
	protected Vector<GamerAttack> gaVector = new Vector<GamerAttack>();
	private GameObjectHandler gameObjects;
	
	public GamerServer(int port) {
		try {
			//this.gameObjects = new GameObjectHandler(PlayingField.tileWidth, PlayingField.tileHeight);
			ServerSocket ss = new ServerSocket(port);
			int id = 1;
			while(true) {
				System.out.println("Waiting for connections...");
				Socket client = ss.accept();
				System.out.println("Connection from " + client.getInetAddress());
				PlayerChar newPlayer = new PlayerChar("Chris");
				//gameObjects.addObject(newPlayer);
				GamerAttack ga = new GamerAttack(client,this);
				gaVector.add(ga);
				
				this.sendPlayerCharacter(newPlayer, ga);
				//if(gaVector.size() == 2){
					//this.sendObject(gameObjects);
					//this.sendObject(this);
				//}
				id++;
				
				ga.start();
				
				
			}
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
		
	}
	public void sendObject(Object o, GamerAttack g){
		for(GamerAttack ga : gaVector) {
			if (!g.equals(ga)) {
				ga.send(o);
			}
		}
	}
	public void sendObject(Object o){
		for(GamerAttack ga : gaVector) {
				ga.send(o);
		}
	}
	/*public void sendMessage(String message){
		for(GamerAttack ga : gaVector) {
				ga.send(message);
		}
	}*/
	public void sendPlayerCharacter(PlayerChar player, GamerAttack g) {
		for(GamerAttack ga : gaVector) {
			if (g.equals(ga)) {
				System.out.println("here");
				ga.send(player);
			}
		}
	}
	public void sendMessage(String message, GamerAttack g) {
		for(GamerAttack ga : gaVector) {
			if (!g.equals(ga)) {
				ga.send(message);
			}
		}
	}
	public void removeChatThread(GamerAttack ct) {
		gaVector.remove(ct);
	}
	public static void main(String [] args) {
		new GamerServer(6789);
	}
}
