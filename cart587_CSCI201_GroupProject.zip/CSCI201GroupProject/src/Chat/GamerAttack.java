package Chat;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;

import temporary.GameObjectHandler;

public class GamerAttack extends Thread implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1206823870087279244L;
	transient private Socket client;
	private GamerServer gs;
	transient private PrintWriter pw;
	transient private ObjectOutputStream oos;
	private GameObjectHandler objects;
	
	public GamerAttack(Socket client,GamerServer gs){
		this.client = client;
		this.gs = gs;
		try {
			this.oos = new ObjectOutputStream(client.getOutputStream());
		} catch (IOException ioe) {
			System.out.println("ioe in ChatThread: " + ioe.getMessage());
		}
		
	}
	public void setHandler(GameObjectHandler goh){
		this.objects = goh;
	}
	public void send(Object o) {
		try {
			oos.reset();
			oos.writeObject(o);
			oos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void send(String message) {
		pw.println(message);
		pw.flush();
	}
	
	public void run() {
		// a client has connected to the server
		try {
			//BufferedReader br = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
			ObjectInputStream ois = new ObjectInputStream(this.client.getInputStream());
			System.out.println("FUCKKKK BRUH");
			while(true) {
				//String line = br.readLine();
				Object o = ois.readObject();
				gs.sendObject(o, this);
			}
		} catch (IOException | ClassNotFoundException ioe) {
			gs.removeChatThread(this);
			System.out.println("Client disconnected from " + this.client.getInetAddress());
		}
	}
}
