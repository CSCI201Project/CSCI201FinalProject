package project2;

import imageProcessing.BufferedImageLoader;
import imageProcessing.Camera;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.Vector;

import javax.swing.ImageIcon;

import weapons.Ammo;
import weapons.Gun;
import weapons.Rifle;
import AStarSearch.AStarTest;
import characters.AlphaZombie;
import characters.PlayerChar;
import characters.Zombie;

public class PlayingField extends Canvas implements Runnable{
	static public int windowWidth;
	static public int windowHeight;
	private TimerThread timer;
	private GameObjectHandler gameObjects;
	private BufferedImage level = null;
	private AStarTest mainMap;
	private Camera cam;
	private Random rand;
	private boolean gameOver = false;
	private int counter = 0;
	private int alphaCounter = 0;
	private int ammoCounter = 0;
	private int spawnDelay = 5;
	private int ammoSpawnDelay = 20;
	private int alphaSpawnDelay = 10;
	static public int tileHeight = 55;
	static public int tileWidth = 55;
	
	
	public PlayingField(TimerThread timer){
		this.timer = timer;
		this.rand = new Random();
		this.setBackground(Color.BLACK);
		gameObjects = new GameObjectHandler(tileWidth,tileHeight);
		gameObjects.setPlayingField(this);
		this.mainMap = new AStarTest();
		
		for(int i = 0; i<mainMap.width; i++){
			for(int j = 0; j<mainMap.height;j++){
				mainMap.mapTiles[i][j] = true;
			}
		}
	}
	public static void removeKeyListener(PlayingField pf, PlayerChar player){
		pf.removeKeyListener(player.getKeyAdapter());
	}
	public static void addKeyListener(PlayingField pf, PlayerChar player){
		pf.addKeyListener(player.getKeyAdapter());
	}
	public static void respawnPlayer(PlayingField pf, PlayerChar player){
			boolean playerSpawned = false;
			while(!playerSpawned){
				int col = pf.rand.nextInt(pf.mainMap.width);
				int row = pf.rand.nextInt(pf.mainMap.height);
				
				if(pf.mainMap.mapTiles[col][row] == true){
					playerSpawned = true;
					player.setX(col * PlayingField.tileWidth);
					player.setY(row * PlayingField.tileHeight);
				}
			}
	}
	private void spawnZombies(){
		if(this.gameObjects.canSpawnZombies() && !this.gameOver){
			int numZombies = 2;
			for(int i = 0; i < numZombies; i++){
				boolean zombieSpawned = false;
				while(!zombieSpawned){
					int col = this.rand.nextInt(this.mainMap.width);
					int row = this.rand.nextInt(this.mainMap.height);
					
					if(mainMap.mapTiles[col][row] == true){
						zombieSpawned = true;
						Zombie tempZombie = new Zombie(col*this.tileWidth, row*this.tileHeight, ObjectId.NormalZombie);
						this.gameObjects.addObject(tempZombie);
						tempZombie.setMap(this.mainMap.mapTiles);
						tempZombie.setTarget(this.gameObjects.player);
						System.out.println("ZOMBIE ADDED!!");
						
						Thread t = new Thread(tempZombie);
						gameObjects.aiThreads.add(t);
						t.start();
					}
				}
			}
		}
	}
	private void spawnAlphaZombies(){
		if(this.gameObjects.canSpawnAlphaZombies() && !this.gameOver){
			int numZombies = 1;
			for(int i = 0; i < numZombies; i++){
				boolean zombieSpawned = false;
				while(!zombieSpawned){
					int col = this.rand.nextInt(this.mainMap.width);
					int row = this.rand.nextInt(this.mainMap.height);
					
					if(mainMap.mapTiles[col][row] == true){
						zombieSpawned = true;
						AlphaZombie tempZombie = new AlphaZombie(col*this.tileWidth, row*this.tileHeight, ObjectId.AlphaZombie);
						this.gameObjects.addObject(tempZombie);
						tempZombie.setMap(this.mainMap.mapTiles);
						tempZombie.setTarget(this.gameObjects.player);
						System.out.println("ALPHA ADDED!!");
						
						Thread t = new Thread(tempZombie);
						gameObjects.aiThreads.add(t);
						t.start();
					}
				}
			}
		}
	}
	private void spawnAmmo(){
		if(this.gameObjects.canSpawnAmmo() && !this.gameOver){
				boolean ammoSpawned = false;
				while(!ammoSpawned){
					int col = this.rand.nextInt(this.mainMap.width);
					int row = this.rand.nextInt(this.mainMap.height);
					
					if(mainMap.mapTiles[col][row] == true){
						this.gameObjects.addObject(new Ammo(col*this.tileWidth, row*this.tileHeight, ObjectId.Ammo));
						ammoSpawned = true;
						System.out.println("AMMO ADDED!!");
					}
				}
			}
	}
	private void init(){
		windowWidth = this.getWidth();
		windowHeight = this.getHeight();
		
		BufferedImageLoader loader = new BufferedImageLoader();
		level = loader.loadImage("res/map.png"); //Loading the map
		LoadImageMap(level);
		gameObjects.init(mainMap.mapTiles);
		this.cam = new Camera(0,0);
		PlayingField.addKeyListener(this, gameObjects.player);
		gameObjects.startAI();
	}
	public void endGame(){
		this.gameOver = true;
		gameObjects.stopAI();
		this.removeKeyListener(gameObjects.getController());
		gameObjects.player.setVelX(0);
		gameObjects.player.setVelY(0);
		
		//String results = "The match has ended! Thank you for playing our game!";
		//int choice = JOptionPane.showConfirmDialog(this, results, "Game Over!", JOptionPane.OK_OPTION);
	}
	public void run() {
		this.init();
		
		//Game Loop that updates the screen and FPS constantly (Taken from RealTutsGML Youtube Channel)
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountOfTicks = 50.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int updates = 0;
		int frames = 0;
		
		while(true){//!this.gameOver){
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta>=1){
				update();
				updates++;
				delta--;
			}
			render();
			frames++;
			
			if(System.currentTimeMillis() - timer > 1000){
				timer +=1000;
				//System.out.println("FPS:" + frames + " TICKS: "+ updates);
				frames = 0;
				updates = 0;
			}
		}
	}

	private void update() {
		gameObjects.update(cam);
		this.counter++;
		this.ammoCounter++;
		this.alphaCounter++;
		
		if(this.counter == (this.spawnDelay*60)){
			this.spawnZombies();
			this.counter = 0;
		}
		if(this.alphaCounter == (this.alphaSpawnDelay*60)){
			this.spawnAlphaZombies();
			this.alphaCounter = 0;
		}
		if(this.ammoCounter == (this.ammoSpawnDelay*60)){
			this.spawnAmmo();
			this.ammoCounter = 0;
		}
	}
	
	private void render(){
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null){
			final int NUM_BUFFERS = 3;
			this.createBufferStrategy(NUM_BUFFERS);
			this.timer.start();
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g;
		//////Actual Graphics///////
		g.setColor(new Color(78, 35, 0));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		g2d.translate(cam.getX(),cam.getY());
		
		gameObjects.render(g);//Most rendering happens here
		g2d.translate(-cam.getX(),-cam.getY());
		
		//Time Display Information
		g.setFont(new Font("Arial",Font.BOLD, 18));
		g.setColor(Color.WHITE);
		if(timer.numSecs < 60)
			g.setColor(Color.red);
		if(timer.secsRemaining < 10)
			g.drawString(this.timer.minRemaining+":0"+this.timer.secsRemaining, this.getWidth()/2 - 10, 45);
		else
			g.drawString(this.timer.minRemaining+":"+this.timer.secsRemaining, this.getWidth()/2 - 10, 45);
		if(timer.numSecs == 0){
			this.endGame();
		}
		////////////
		g.dispose();
		bs.show();
	}
	private void LoadImageMap(BufferedImage image){
		int w = this.mainMap.width;
		int h = this.mainMap.height;
		for(int row = 0; row < h; row++){
			for(int col = 0; col < w; col++){
			
				int pixel = image.getRGB(col, row);
				int red = (pixel >> 16) & 0xff;
				int green = (pixel >> 8) & 0xff;
				int blue = (pixel) & 0xff;
			
				if(red == 255 && green == 255 && blue == 255){
					gameObjects.addObject(new Bush(col*this.tileWidth, row*this.tileHeight, ObjectId.Bush));
					mainMap.loadMap(row, col,false);
				}
				else if(red == 0 && green == 255 && blue == 0){
					gameObjects.addObject(new Tree(col*this.tileWidth, row*this.tileHeight, ObjectId.Tree));
					mainMap.loadMap(row, col,true);
				}
				else if(red == 64 && green == 64 && blue == 64){
					gameObjects.addObject(new Tombstone(col*this.tileWidth, row*this.tileHeight, ObjectId.Tombstone));
					mainMap.loadMap(row, col,false);
				}
				else if(red == 192 && green == 192 && blue == 192){
					gameObjects.addObject(new Cross(col*this.tileWidth, row*this.tileHeight, ObjectId.Cross));
					mainMap.loadMap(row, col,false);
				}
				else if (red == 48 && green == 48 && blue == 48){
					mainMap.loadMap(row, col,false);
				}
				else if(red == 255 && green == 0 && blue == 0){
					gameObjects.addObject(new Zombie(col*this.tileWidth, row*this.tileHeight, ObjectId.NormalZombie));
				}
				else if (red == 0 && green == 0 && blue == 255){
					gameObjects.addObject(new Ammo(col*this.tileWidth, row*this.tileHeight, ObjectId.Ammo));
				}
				else if (red == 0 && green ==255  && blue == 255){
					gameObjects.addObject(new Rifle(col*this.tileWidth, row*this.tileHeight, ObjectId.Rifle));
				}
				else if (red == 255 && green == 0 && blue == 255){
					gameObjects.addObject(new Gun(col*this.tileWidth, row*this.tileHeight, ObjectId.Shotgun));
				}
				else if(red == 255 && green == 106 && blue == 0){
					gameObjects.startX = col*this.tileWidth;
					gameObjects.startY = row*this.tileHeight;
				}
			}
		}
	}	
}


class Tree extends GameObject{

	public Tree(double x, double y,ObjectId id) {
		super(id);
		this.x = x;
		this.y = y;
		this.width = 100;
		this.height = 100;
	}

	public void render(Graphics g) {
		ImageIcon icon = new ImageIcon("images/tree.png","tree");
		Image image = icon.getImage();
		g.drawImage(image, (int)this.x, (int)this.y, null);
		
	}

	public void update(Vector<GameObject> objects) {
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 100, 100);
	}
}
class Bush extends GameObject{

	public Bush(double x, double y,ObjectId id) {
		super(id);
		this.x = x;
		this.y = y;
		this.width = 50;
		this.height = 45;
	}

	public void render(Graphics g) {
		ImageIcon icon = new ImageIcon("images/bush.png","bush");
		Image image = icon.getImage();
		g.drawImage(image, (int)this.x, (int)this.y, null);
	}

	public void update(Vector<GameObject> objects) {
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 50, 45);
	}
}
class Tombstone extends GameObject{

	public Tombstone(double x, double y,ObjectId id) {
		super(id);
		this.x = x;
		this.y = y;
		this.width = 50;
		this.height = 50;
	}

	public void render(Graphics g) {
		ImageIcon icon = new ImageIcon("images/tombstone.png","tombstone");
		Image image = icon.getImage();
		g.drawImage(image, (int)this.x, (int)this.y, null);
	}

	public void update(Vector<GameObject> objects) {
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 50, 50);
	}
}
class Cross extends GameObject{

	public Cross(double x, double y,ObjectId id) {
		super(id);
		this.x = x;
		this.y = y;
		this.width = 50;
		this.height = 50;
	}

	public void render(Graphics g) {
		ImageIcon icon = new ImageIcon("images/cross.png","cross");
		Image image = icon.getImage();
		g.drawImage(image, (int)this.x, (int)this.y, null);
	}

	public void update(Vector<GameObject> objects) {
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 50, 50);
	}
}