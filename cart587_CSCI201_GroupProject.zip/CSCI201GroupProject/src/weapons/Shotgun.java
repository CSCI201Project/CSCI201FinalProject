package weapons;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Vector;

import project2.GameObject;
import project2.ObjectId;

public class Shotgun extends Weapon{

	public Shotgun(ObjectId id) {
		super(id);
		this.currentAmmoCount = 5;
		this.maxAmmoCount = 15;
		this.ammoFromPickup = 5;
		this.bulletDamage = 100;
		this.fireRate = 0.5; //per second
		canFire = true;
	}

	public Bullet fireWeapon(int bulletX, int bulletY, String direction) {
		// TODO Auto-generated method stub
		if (canFire){
			currentAmmoCount = currentAmmoCount -1;
			return new Bullet(ObjectId.Bullet, bulletX, bulletY, bulletDamage, true, direction);
		}
		else return null;
		

	}

	public void addAmmo() {
		// TODO Auto-generated method stub
		currentAmmoCount += ammoFromPickup;
		if (currentAmmoCount > maxAmmoCount){currentAmmoCount = maxAmmoCount;}
	}

}
