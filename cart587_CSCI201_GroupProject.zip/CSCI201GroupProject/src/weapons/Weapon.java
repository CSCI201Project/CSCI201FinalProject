package weapons;

import project2.GameObject;
import project2.ObjectId;

public abstract class Weapon extends GameObject{
	protected int currentAmmoCount;
	protected int maxAmmoCount;
	protected int ammoFromPickup; 
	protected int bulletDamage;
	protected double fireRate;
	protected boolean canFire;  
	
	public Weapon(ObjectId id) {
		super(id);
	}
	
	public abstract void fireWeapon();
	public abstract void addAmmo();
	
	public boolean outOfAmmo(){
		return currentAmmoCount == 0;
	}
}


