package weapons;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Vector;

import project2.GameObject;
import project2.ObjectId;

public class Bullet extends GameObject{
	int direction;
	int originX, originY;
	
	public Bullet(ObjectId id) {
		super(id);
	}
	/*public Bullet(int direction, int x, int y){

	}*/
	public void fire(){
		
	}
	private void findTarget(Vector<GameObject> objects){
		
	}
	public void addObject(){
		
	}
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}
	public void update(Vector<GameObject> objects) {
		// TODO Auto-generated method stub
		
	}
	public Rectangle getBounds() {
		// TODO Auto-generated method stub
		return null;
	}
}

